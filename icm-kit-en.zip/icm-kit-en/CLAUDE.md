# Workspace Router (L0)

> ICM Layer 0. Routes any task to the right workspace and stage. Always loaded.

## Job routing
| Intent | Where to go |
|---|---|
| Daily brief | `brief` / `/brief` |
| Weekly review | `review` / `/review` |
| New client (per project) | `/new-client <name>` → copy `clients/_template/` to `clients/<name>/` |
| Produce a project for a client | `/new-campaign <client>` → start in `stages/01-research/` |
| Audit tone / validate a delivery | `/brand-check <file or text>` |
| Work inside the active stage | `stages/NN-{name}/CONTEXT.md` |
| Work with an existing client | `clients/{client}/CONTEXT.md` |
| Capture a learning / update the OS | `memory/learnings.md` |

## Mandatory reads (session start)
- `CONTEXT.md`, the L1 load table

## What NOT to load (session start)
- `archive/**`, legacy documents
- `stages/**/output/`, Layer 4, load only inside the active stage
- `clients/*/stages/**/output/`, same
- `node_modules`, build folders, `.agents/`

## Conventions (non-negotiable)
- **Pricing floor:** see `shared/references/pricing.md`. Always a written agreement first.
- **Voice:** `shared/references/voice.md` is the single source of truth.
- **Tool routing:** `shared/references/tool-routing.md` decides which tool to use.

## Stage progression (the pipeline)
`01-research` → `02-strategy` → `03-direction` → `04-production` → `05-delivery`

Every stage has its own `CONTEXT.md` with Input → Process → Output → Completion.

## Memory (persists between sessions)
- `memory/clients/{client}.md`, final log per client (amount, learnings, status)
- `memory/learnings.md`, cross-project insights
- `memory/prompts/prompts-that-worked.md`, library of prompts that produced exceptional results

## Triggers (single word)
| Trigger | Action |
|---|---|
| `brief` | Status + 3 priorities for today + 1 strategic question |
| `review` | Weekly recap + blockers + learnings + next 3 priorities |

## Model strategy

| Phase | Model | Effort | When |
|---|---|---|---|
| 🧠 PLANNING (plan mode) | Your strongest model | Max | Project architecture, complex decisions |
| ⚡ EXECUTION | The fast model | High (default) | Copy, prompts, editing files |
| 🔍 QUICK SCAN | Fast mode | Low | Review a brief, scan references |
| 📄 MULTIMODAL | Your strongest model | High | Analyze client PDFs |
| ⬆️ ESCALATION | Your strongest model | Extra | A hard blocker → solve it, then go back to the fast model |

### Protocol (mandatory): always state the model

**At the start of every answer**, show a visible block with the phase and the model it calls for. Announce it again whenever the phase changes:

```
🧠 PLANNING  → strongest model · Effort Max    (plan mode)
⚡ EXECUTION → fast model · Effort High         (implementing)
🔍 SCAN      → fast mode · Effort Low
⬆️ ESCALATE  → strongest model · Effort Extra
```

Rules:
- **Plan mode = strongest model** (plan, decide architecture). **Execution = fast model** (write, edit, produce). Announce the switch when you move from planning to executing.
- The agent **does not switch models on its own**: it says which one applies and **the user changes it in the app's selector**. The block is the reminder.
- If for any reason you are not on the recommended model, say so anyway ("I'm on the fast model, this would be better on the strongest one") so the user can decide.
