# {{STUDIO_NAME}}. Tool Routing Table

> Load when: you have to decide which tool / skill / subagent to use for an intent.
> This file is yours: change it to match the tools you actually use.

---

## Quick decision by intent

| Intent | Tool / action | When NOT |
|---|---|---|
| Research a client / competitor | `WebFetch` + web search | If you already have the info |
| Audit the tone of a text | Subagent `brand-guardian` (if you set it up) | Internal drafts only |
| Review before client delivery | Subagent `deliverable-reviewer` | Unpolished drafts |
| Automate a recurring workflow | Your automation tool | One-off manual tasks |
| Generate image / video (if it applies) | Your preferred generation tool | |
| Build / update a website | Your preferred web tool | |
| Multi-file research | Subagent `Explore` (built into Claude Code) | A single-file lookup |

## Decision by pipeline stage

| Stage | Main action | Output goes to |
|---|---|---|
| 01-research | WebFetch, research, benchmarking | `stages/01-research/output/` |
| 02-strategy | Working session with Claude, concept development | `stages/02-strategy/output/` |
| 03-direction | Define direction, build prompts / briefs | `stages/03-direction/output/` |
| 04-production | Execution with external tools | `stages/04-production/output/` |
| 05-delivery | Copy, packaging, final review | `stages/05-delivery/output/` |

## Routing rules
1. **One tool per intent.** If two seem to apply, pick the more specific one.
2. **Subagents do NOT execute production.** They only audit / review / plan.
3. **Before any final delivery:** go through a tone and completeness review.
4. **If you are torn between tools:** ask Claude directly, "which tool would you use for X?".

## My tools (fill in)
<!-- List the tools you really use in your business. -->

| Tool | What for |
|---|---|
| {{TOOL_1}} | {{USE_1}} |
| {{TOOL_2}} | {{USE_2}} |
| {{TOOL_3}} | {{USE_3}} |
