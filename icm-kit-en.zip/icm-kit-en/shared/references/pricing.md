# {{STUDIO_NAME}}. Pricing (single source of truth)

> ★ FILL IN this file before using the system.
> Load when: commercial conversations, proposals, quotes.

---

## Services / products
<!-- One line per offer: what it is, what it includes, what it does not include. -->

| Offer | Includes | Does not include | Price |
|---|---|---|---|
| {{OFFER_1}} | {{INCLUDES_1}} | {{EXCLUDES_1}} | {{PRICE_1}} |
| {{OFFER_2}} | {{INCLUDES_2}} | {{EXCLUDES_2}} | {{PRICE_2}} |
| {{OFFER_3}} | {{INCLUDES_3}} | {{EXCLUDES_3}} | {{PRICE_3}} |

## Floor (non-negotiable)
<!-- The minimum you accept for a project. Below this, say no. -->

{{FLOOR}}

## Payment structure
- {{PERCENT}}% upfront, the rest on delivery
- Always a written agreement before starting
- Currency and invoicing: {{CURRENCY_AND_INVOICING}}

## Sales rules
- Never quote in the first conversation. Understand first, quote after.
- Every quote names the deliverables, the deadline and what is out of scope.
- Extra rounds of changes: {{CHANGE_ROUNDS_POLICY}}
