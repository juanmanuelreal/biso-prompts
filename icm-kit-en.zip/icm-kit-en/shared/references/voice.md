# {{STUDIO_NAME}}. Voice (single source of truth)

> ★ FILL IN this file before using the system.
> Load when: any output with text aimed at the client or the public.

---

## Tone
<!-- Describe the tone in 3 to 5 adjectives. Be specific: not "professional", but what kind of professional. -->
<!-- Example: "Direct · warm · no fluff. Talks like someone who knows a lot but does not show off." -->

{{TONE}}

## Forbidden phrases. NEVER use
<!-- The words and phrases that must never appear in your brand's communication. -->
<!-- If one shows up in a draft → rewrite before delivering. -->

- {{FORBIDDEN_PHRASE_1}}
- {{FORBIDDEN_PHRASE_2}}
- {{FORBIDDEN_PHRASE_3}}
- Anything that sounds like a Canva template or generic AI
- "As experts in..."
- "We are passionate about..."

## Phrases that DO sound like {{STUDIO_NAME}}
<!-- Concrete examples of how your brand DOES sound. -->

- "{{YES_PHRASE_1}}"
- "{{YES_PHRASE_2}}"
- "{{YES_PHRASE_3}}"

## Output rules
<!-- What to avoid in every output, whatever the format. -->

- No generic outputs
- No empty corporate jargon
- No promises you cannot measure
- No obvious AI filler ("Understood", "Of course", "Sure!")
- No endless lists when a paragraph works better

## Rules for communicating with clients
<!-- How you talk to clients: email, proposal, follow-up. -->

- {{COMMUNICATION_RULE_1}}
- {{COMMUNICATION_RULE_2}}
- {{COMMUNICATION_RULE_3}}

## Language / bilingual
<!-- If you work in more than one language, say so. -->

- **Internal documents / client communication / copy:** {{OPS_LANGUAGE}}
- **AI prompts (if you generate content):** English. Always.

## Self-audit
Before delivering any output with text: check it against "Forbidden phrases".
If one appears → rewrite. Do not patch, rewrite.
