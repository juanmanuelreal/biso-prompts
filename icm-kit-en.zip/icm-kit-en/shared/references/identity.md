# {{STUDIO_NAME}}. Identity (single source of truth)

> ★ FILL IN this file before using the system.
> Load when: any stage that uses brand voice, identity or positioning.

---

## What {{STUDIO_NAME}} is
<!-- One sentence that captures exactly what you do and for whom. -->
<!-- Example: "A strategic design studio that turns mid-sized brands into references in their industry." -->

{{BUSINESS_DESCRIPTION}}

## Founders / team
<!-- Who they are, the role of each one, what you specifically bring. -->

- **{{NAME_1}}**, {{ROLE}}, {{WHAT_THEY_DO}}
- **{{NAME_2}}**, {{ROLE}}, {{WHAT_THEY_DO}}

## Public anchors
<!-- Where you exist online and how you present yourself. -->

- Site / main channel: `{{URL_OR_HANDLE}}`
- Tagline (internal): `{{INTERNAL_TAGLINE}}`
- Tagline (external): `{{EXTERNAL_TAGLINE}}`
- One-liner: `{{ONE_LINER}}`
- Exact positioning: `{{POSITIONING}}`

## Markets
<!-- Geography and segment where you operate. -->

{{MARKETS}}

## Ideal client
<!-- Who IS the right client: industry, size, mindset. -->

{{IDEAL_CLIENT_DESCRIPTION}}

## NOT for {{STUDIO_NAME}}
<!-- Who is NOT your client. This avoids wasting time on the wrong leads. -->

- {{EXCLUSION_1}}
- {{EXCLUSION_2}}
- {{EXCLUSION_3}}

## Philosophy / non-negotiable values
<!-- The principles that guide every creative or operational decision. -->

- {{VALUE_1}}
- {{VALUE_2}}
- {{VALUE_3}}

## Aesthetics / working style (if it applies)
<!-- Only if your business has a particular visual aesthetic or delivery style. -->

{{AESTHETICS}}

## Commercial insight
<!-- The central idea for which clients pay YOU and not someone else. -->
<!-- Example: "The client does not pay for hours → they pay for result + criteria + direction." -->

{{COMMERCIAL_INSIGHT}}

## Output priorities
<!-- In order: what you prioritize in every delivery. -->

1. {{PRIORITY_1}}
2. {{PRIORITY_2}}
3. {{PRIORITY_3}}
