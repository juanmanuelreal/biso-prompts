# Client. {{CLIENT_NAME}}

> Load when: working on anything for this client. Copy `clients/_template/` to `clients/{{client-name}}/` and fill this in.

## Status
- **Stage:** {{01-research | 02-strategy | 03-direction | 04-production | 05-delivery}}
- **Started:** {{YYYY-MM-DD}}
- **Deadline:** {{YYYY-MM-DD}}
- **Owner:** {{WHO}}

## What this project is
<!-- One paragraph. Goal, scope, what success looks like. -->

{{SUMMARY}}

## Files for this client
| File | What |
|---|---|
| `brief.md` | The original brief. Read at stage 01. |
| `references/brand.md` | The client's brand: tone, palette, approved and rejected references. |
| `deliverables/{YYYY-MM-DD}/` | What was delivered, by date. |

## Deliverables agreed
- {{DELIVERABLE_1}}
- {{DELIVERABLE_2}}

## Open questions
- {{QUESTION_1}}

## Notes
<!-- Anything Claude should know before touching this client's work. -->
-
