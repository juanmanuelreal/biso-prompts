# Brief. {{CLIENT_NAME}}

> Date: {{DATE}}

## Client data
- **Company / brand:**
- **Field / industry:**
- **Market / country:**
- **Web / social:**
- **Contact / decision-maker:**

## Project goal
> One sentence. The business result the client expects.

## What they want to communicate / solve / improve
-

## Audience (in the client's words)
-

## Expected deliverables
- Deliverable 1:
- Deliverable 2:
- Others:

## Deadline
> If there is real urgency, say so here.

## References the client gave
-

## Restrictions / no-go
> Things the client explicitly does NOT want.
-

## Agreed budget
- Total: $
- Product: {{PRODUCT}}
- Payment: {{PERCENT}}% upfront $ (date) + the rest on delivery $ (date)

## Internal notes (do not share with the client)
- Lead qualification (real signals / red flags):
- Why this client is right for my business:
- Risks detected:
