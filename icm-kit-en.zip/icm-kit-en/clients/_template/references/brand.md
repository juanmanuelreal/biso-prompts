# Brand Reference. {{CLIENT_NAME}}

> Fill in with the client's brand information. Source: brand manual, site, brief or conversation.

## Identity
- **Brand name:**
- **Tagline / slogan:**
- **One-liner (how they describe themselves):**

## The client's tone of voice
<!-- How the client's brand speaks. This is INDEPENDENT of how your business speaks. -->
-

## Color palette
- Primary:
- Secondary:
- Neutral:

## Typefaces (if known)
-

## Visual aesthetics
<!-- The style of photos, videos, illustrations the brand uses. -->
-

## References the client approved
<!-- URLs or descriptions of things the client said "I want something like this". -->
-

## References the client rejected
<!-- Things they explicitly do not want. -->
-

## Additional notes
-
