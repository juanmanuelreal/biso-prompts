# START HERE. Install from zero

> For people who know nothing technical. Follow the steps in order. Total time: about 20 minutes.

## What you get at the end
An assistant (Claude) that knows your business, keeps your clients and projects in order, helps you write proposals and quotes, and walks each project through five stages. All from one folder on your computer.

## Before you start: the only thing you pay for
Claude Code needs a paid Claude account (Pro or Max). The free plan does not work with this.
1. Go to claude.com and create your account.
2. Subscribe to Pro. It is enough to start.
3. Keep your login handy. You will use it in step 2.

## Two ways to use this. Pick one.
- **Desktop app (recommended):** windows and mouse, no terminal. Go to PATH A.
- **Terminal:** more commands, more control. Go to PATH B.

---

# PATH A. The desktop app

### A.1 Download the app
Go to claude.com/download and install the Claude app like any other program.

### A.2 Sign in
Open the app and sign in with your paid account.

### A.3 Open the folder
In the app, choose "open folder" and select the `icm-kit` folder (or whatever you renamed it to).

### A.4 Test it
Type `brief` in the chat. If it answers with a status and priorities, it works. Jump to STEP 5.

---

# PATH B. The terminal

## STEP 1. Install Claude Code (10 min)
1. Press `Cmd + Space`, type **Terminal**, press Enter. A window with text opens. That is the terminal. You will only paste things into it.
2. Copy this line, paste it in the terminal and press Enter:
```
curl -fsSL https://claude.ai/install.sh | bash
```
Wait for it to finish. It may take a couple of minutes and print a lot of text. That is normal.
3. Close the terminal, open it again, paste this and press Enter:
```
claude --version
```
If you see a number, it is installed.

## STEP 2. Sign in (2 min)
In the terminal type `claude`. The first time it asks you to sign in. The browser opens, sign in with your paid account, come back to the terminal.

## STEP 3. Put the folder in its place (2 min)
1. The folder is called `icm-kit`. Rename it to your business name if you like (for example `my-studio`).
2. Move it somewhere easy to find, like your Desktop.
3. In the terminal, "enter" that folder:
```
cd ~/Desktop/my-studio
```
Tip: type `cd ` (with the space), then drag the folder from Finder into the terminal and press Enter. The path fills itself in.

## STEP 4. Open your assistant (1 min)
Inside the folder, type:
```
claude
```
Claude starts and reads your business setup on its own. Test it:
```
brief
```
It gives you a status and priorities. If it answers, everything works.

## STEP 5. Fill in your information (15 min, once)
Three files define your business. Ask Claude to help you fill them. Type:
```
Help me complete shared/references/identity.md with my business info. Ask me the questions one at a time.
```
Repeat for the other two:
- `shared/references/voice.md` (how you communicate)
- `shared/references/pricing.md` (your services and prices)

You do not write the files yourself. Claude asks the questions and fills them for you.

## How to work from now on
1. Open the terminal (or the app).
2. Enter your folder: `cd ~/Desktop/my-studio`.
3. Type `claude`.
4. Ask for what you need, in plain language.

| Type this | And it does |
|---|---|
| `brief` | Status of the day plus priorities |
| `review` | Weekly recap |
| `/new-client name` | Creates the file for a new client |
| `/new-campaign name` | Starts a project for that client |

## If you get stuck
Paste the error into Claude and ask what it means. Do not delete or move files in the folder unless you are sure.

**Next file to read:** `README.md`, it explains how everything is organized.
