# ICM Kit. Intelligent Context Management for Claude Code

This kit is a folder system designed to work with **Claude Code** in a structured, efficient and scalable way. It works as an "operating system" for your business inside the editor.

---

## What is ICM?

**ICM (Intelligent Context Management)** is a way to organize the context Claude receives in every session. Instead of explaining everything from scratch each time, the system loads the right files for the task at hand.

There are four layers:
- **L0**: `CLAUDE.md` (the main router, always loaded)
- **L1**: `CONTEXT.md` (the load table: what to load and when)
- **L2**: `stages/` and `clients/` (one workspace per project)
- **L3**: `shared/references/` (the persistent knowledge base)

---

## Install in 3 steps

### 1. Copy the folder
```bash
cp -r icm-kit/ ~/your-business/
cd ~/your-business/
```

### 2. Fill in the reference files
These are the only files you must complete before you start:

| File | What to fill in |
|---|---|
| `shared/references/identity.md` | Name, description, founders, value proposition |
| `shared/references/voice.md` | Tone, forbidden phrases, phrases that DO sound like your brand |
| `shared/references/pricing.md` | Your products or services, prices, sales rules |

Everything else (`CLAUDE.md`, `CONTEXT.md`, `stages/`) is ready to use.

### 3. Open Claude Code inside the folder
```bash
claude   # inside ~/your-business/
```
Claude reads `CLAUDE.md` automatically when the session starts.

---

## Daily use

### Main commands

| What you want | How to say it |
|---|---|
| Daily brief | `brief` (no slash) or `/brief` |
| Weekly review | `review` (no slash) or `/review` |
| New client | `/new-client client-name` |
| Produce a project for a client | `/new-campaign client-name` |
| Audit the tone of a text | `/brand-check [paste the text or a file path]` |

### The project flow (pipeline)
```
01-research → 02-strategy → 03-direction → 04-production → 05-delivery
```
Every stage has its own `CONTEXT.md` with instructions: what to do, which tools to use and what output is expected. Claude follows each stage's contract without you having to explain it.

**The pipeline is agnostic. It adapts to any project-based business.** A services business maps like this:

| Generic stage | In a services business |
|---|---|
| 01-research | Survey the client, the site, the need |
| 02-strategy | Define the approach and scope |
| 03-direction | Design, direction, visual proposal |
| 04-production | Doing the work |
| 05-delivery | Delivery, close, follow-up |

Rename the stages if your field calls them something else. The system works the same.

---

## Folder structure

```
your-business/
├── START-HERE.md                  ← install from zero (READ FIRST)
├── CLAUDE.md                      ← L0 router (always loaded by Claude Code)
├── CONTEXT.md                     ← L1 load table
├── shared/
│   └── references/
│       ├── identity.md            ← ★ FILL IN: your business identity
│       ├── voice.md               ← ★ FILL IN: tone and phrases
│       ├── pricing.md             ← ★ FILL IN: prices and sales rules
│       └── tool-routing.md        ← which tool for which intent
├── stages/                        ← generic pipeline (reused per project)
│   ├── 01-research/
│   ├── 02-strategy/
│   ├── 03-direction/
│   ├── 04-production/
│   └── 05-delivery/
├── clients/
│   └── _template/                 ← copy and rename for every new client
│       ├── CONTEXT.md
│       ├── brief.md
│       └── references/brand.md
└── memory/
    ├── learnings.md               ← cross-project insights
    ├── clients/                   ← one log per client (amount, lessons, status)
    └── prompts/
        └── prompts-that-worked.md
```

---

## Model strategy

| Phase | Recommended model | When |
|---|---|---|
| Planning | Your strongest model, max effort | Project architecture, complex decisions |
| Execution | The fast model, high effort | Copy, prompts, editing files |
| Quick scan | Fast mode | Reviewing a brief, scanning references |
| Multimodal | Your strongest model | Analyzing client PDFs |
| Escalation | Your strongest model, extra effort | A hard blocker |

---

## FAQ

**Does it work for any field?**
Yes. The system is agnostic. You only fill in `identity.md`, `voice.md` and `pricing.md` with your business.

**What do I need to install?**
Only Claude Code and a paid Claude account.

**Do I have to use all the stages?**
No. If your business does not have a five-phase pipeline, delete the stages you do not use and rename the ones you do.

**Can I rename folders?**
Yes, but if you change names you must update the references in `CLAUDE.md` and `CONTEXT.md`.
