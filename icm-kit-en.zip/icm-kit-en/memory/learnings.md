# Learnings. Cross-project

> Insights captured after real projects. Update after every delivery.
> No theory. Only things you learned by doing.

---

## Operations / sales

_(empty. Fill in after the first project)_

## Production / execution

_(empty)_

## Clients / relationships

_(empty)_

## Tools / workflow

_(empty)_

---

## Format for adding a learning

```
### [YYYY-MM-DD]. {short title}
**Context:** what happened
**Learning:** what changes in how you operate from now on
**Applies to:** (sales / production / tools / clients)
```
