# Prompts / briefs that worked

> Save here any prompt, brief or instruction that produced an exceptional result.
> This is your reproducibility library. What worked once can work again.

---

## Format for adding an entry

```
### [YYYY-MM-DD]. {descriptive name}
**Project:** {client or context}
**Tool / context of use:** {where it was used}
**Why it worked:** {1-2 sentences}

---PROMPT / BRIEF---
{exact content}
---END---
```

---

_(empty. Fill in with your first exceptional result)_
