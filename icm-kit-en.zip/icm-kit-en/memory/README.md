# Memory

What persists between sessions. Claude reads these when the router says so, and updates them at the end of a project.

- `learnings.md`, cross-project insights. Only things you learned by doing.
- `clients/{client}.md`, one log per client: amount billed, lessons, status.
- `prompts/prompts-that-worked.md`, every prompt or brief that produced an exceptional result.
