# Workspace. Load Table (L1)

> ICM Layer 1. Declares what gets loaded, when and why, for the active session.

## What to load
| Resource | When | Why |
|---|---|---|
| `shared/references/identity.md` | Always (session start) | The business's voice and positioning |
| `shared/references/voice.md` | Any output with text | Tone filter and forbidden phrases |
| `shared/references/pricing.md` | Commercial conversations / proposals | Floor and non-negotiable structure |
| `shared/references/tool-routing.md` | Deciding which tool to use | Intent → tool mapping |
| `clients/{client}/CONTEXT.md` | Client with an active project | Brief, status, deliverables |
| `clients/{client}/brief.md` | Starting stage 01 with a client | The original brief |
| `memory/clients/{client}.md` | Client with previous history | Lessons from earlier projects |
| `stages/NN-{name}/CONTEXT.md` | Entering an active stage | The stage contract |

## What NOT to load
- Several `stages/` at once. Load only the active stage.
- Several `clients/{client}/` at once. Load only the active client.
- `stages/**/output/` unless you are reviewing a specific output.

## Stage progression
`01-research` → `02-strategy` → `03-direction` → `04-production` → `05-delivery`

Every stage `CONTEXT.md` declares its own Input / Process / Output. Do not skip stages.

## Subagents (configure in `.claude/agents/`)
You can create subagents for repeated tasks. Useful examples:
- `brand-guardian`, catches off-tone phrases before delivery
- `deliverable-reviewer`, final review before it reaches the client

See the Claude Code docs: `claude --help` or `/help`.
