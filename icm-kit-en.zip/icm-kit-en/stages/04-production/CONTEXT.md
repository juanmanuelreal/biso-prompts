# Stage 04. Production

> Estimated time: varies with the number of pieces

## Input
| Source | What | Why |
|---|---|---|
| `stages/03-direction/output/briefs/` | Direction briefs | The base for execution |
| `shared/references/tool-routing.md` | Tool routing | Decide which tool to use for each piece |
| `clients/{client}/references/brand.md` | The client's brand | Visual / verbal consistency |

## Process
1. Take each direction brief
2. Execute with the right tool (per `tool-routing.md`)
3. **Apply the quality criteria** before selecting (see below)
4. If no variation passes the criteria → adjust the brief, do not generate more variations of the same one
5. Select the best result
6. Post-process if needed

## Quality criteria (selection)
✅ Looks / sounds real and specific to the client
✅ Meets the goal defined in `strategy.md`
✅ Respects the direction in `direction.md`
✅ Does not look generic or like a template
❌ Discard if: it could belong to any company, it sounds like obvious AI, it does not solve the goal

## Output
Write to `output/`:
- `output/selected/`, the selected pieces with descriptive names
- `output/jobs.md`, a log of what was generated / executed, with links or references

## Completion
- Every selected piece passes the quality criteria
- Next stage: `stages/05-delivery/`
