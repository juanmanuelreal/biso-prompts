# Stage 01. Research

> Estimated time: 2 to 4 h

## Input
| Source | What | Why |
|---|---|---|
| `clients/{client}/brief.md` | The client's initial brief | Project goal, budget, deadline |
| `shared/references/identity.md` | Business identity | Keep voice and positioning |
| `shared/references/voice.md` | Tone + forbidden phrases | Filter language before any output |

## Process
1. Read the client brief (or ask the key questions if it is incomplete)
2. Analyze the client's digital presence: site, social, current communication
3. Identify 3 to 5 relevant references: the ones the client mentioned plus the ones that fit the industry
4. Analyze 1 or 2 direct competitors: what they do, what they lack
5. Identify 1 or 2 aspirational references outside the industry
6. Synthesize: 1 paragraph of context plus a list of key findings

## Suggested tools
- `WebFetch` to analyze the client's and competitors' sites and social
- The `Explore` subagent if references are scattered across the project

## Output
Write to `output/research.md`:
```markdown
# Research. {client}
**Date:** {YYYY-MM-DD}

## Company / brand context
{1 paragraph}

## What they are doing well
- {3-5 bullets}

## What they lack / the opportunity
- {3-5 bullets}

## Differential opportunity
{1 paragraph: what nobody in their industry is using}

## Relevant references (3-5)
- {URL or description + why it applies}

## Strategic question for the client
{1 question that forces the client to clarify direction}
```

## Completion
- Wait for a human review of `output/research.md`.
- Next stage: `stages/02-strategy/`.
