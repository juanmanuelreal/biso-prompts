# Stage 05. Delivery

> Estimated time: 1 to 2 h

## Input
| Source | What | Why |
|---|---|---|
| `stages/04-production/output/selected/` | Final pieces | The material to deliver |
| `stages/02-strategy/output/strategy.md` | Concept + goal | Base for copy and context |
| `shared/references/voice.md` | Tone + forbidden phrases | Filter the copy before delivery |
| `clients/{client}/brief.md` | Original brief | Confirm the goals were met |

## Process
1. **Write copy** for each piece if it applies (3 options per piece maximum)
   - Check against the forbidden phrases in `voice.md` before including it
2. **Write a usage / publishing guide**: order, platform, context of use
3. **Write 1 paragraph of creative context**: the idea behind the project (so the client understands what they received and why)
4. **Package the delivery**: assets + copy + guide in one organized folder
5. **Final review** before sending: tone, completeness, compliance with the brief

## Output
Write to `output/` (or to `clients/{client}/deliverables/{YYYY-MM-DD}/`):
- `assets/`, final pieces in a ready-to-use format
- `copy.md`, copy per piece (if it applies)
- `publishing-guide.md`, usage / publishing instructions
- `creative-context.md`, 1 paragraph on the idea (for the client)

## Completion
- Pass the tone review before sending
- Send the delivery to the client
- Update `memory/clients/{client}.md`: amount billed, 1 learning, status
- If there were exceptional outputs: add them to `memory/prompts/prompts-that-worked.md`
