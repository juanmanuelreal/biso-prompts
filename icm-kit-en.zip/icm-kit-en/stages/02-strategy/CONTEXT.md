# Stage 02. Strategy

> Estimated time: 1 to 2 h

## Input
| Source | What | Why |
|---|---|---|
| `stages/01-research/output/research.md` | Stage 1 output | Context and opportunity |
| `shared/references/identity.md` | Business identity | The concept must align with your brand |
| `shared/references/voice.md` | Tone | Filters concept options |
| `clients/{client}/brief.md` | Original brief | The client's business goal |

## Process
1. Define the **core concept**: ONE idea, one sentence maximum. If it needs more, it is not strong enough.
2. Define the **audience**: real psychographics, not demographics. What they feel, fear, want.
3. Define the **dominant emotion / result**: specific, not generic.
4. Define **formats and scope**: which pieces / deliverables we will produce and why.
5. Define a **measurable business goal**: the concrete action we want from the end customer.

## Output
Write to `output/strategy.md` (one page maximum; if it does not fit, it is overcomplicated):
```markdown
# Strategy. {client}

## Core concept
{1 sentence. One idea that runs through everything.}

## Audience
{Psychographics: desires, fears, contradictions.}

## Result / dominant emotion
{1 specific, measurable result, or 1 specific emotion.}

## Deliverables to produce
- {Deliverable 1: description, format, why}
- {Deliverable 2: ...}

## Measurable business goal
{Which metric / action we want to move.}

## Anti-goal
{What we do NOT want to happen.}
```

## Completion
- Human review. If there is no agreement on the concept, go back to Stage 1.
- **Rule:** concept first. Always. If the idea is weak, do not move forward.
- Next stage: `stages/03-direction/`.
