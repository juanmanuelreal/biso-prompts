# Stage 03. Direction

> Estimated time: 2 to 3 h

## Input
| Source | What | Why |
|---|---|---|
| `stages/02-strategy/output/strategy.md` | Signed-off strategy | Concept and deliverables defined |
| `stages/01-research/output/research.md` | The client's references | Inspiration bank |
| `shared/references/identity.md` | Aesthetics and identity | Coherence with the brand |
| `clients/{client}/references/brand.md` | The client's brand | Respect the client's identity |

## Process
1. Translate the strategy into **concrete direction**: how does each deliverable look, sound or feel?
2. Define specific references: style, palette, visual / verbal tone per piece
3. Write a **brief per deliverable**: concrete instructions for production
4. If there are AI assets (images, video, copy): write the prompts or briefs in this step
5. Validate internally before moving to production

## Output
Write to `output/`:
- `output/direction.md`, direction decisions (style, tone, palette, references per piece)
- `output/briefs/`, one brief per deliverable (`.md` or `.json` depending on the tool)

## Direction rules
- One direction per deliverable. If there are two possible options, pick one.
- Be specific: not "modern", but "sans-serif type, lots of white space, no icons".
- The brief must be executable without asking anything else.

## Completion
- Human review of `output/direction.md`.
- Next stage: `stages/04-production/`.
